/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guessgame;

/**
 *
 * @author Erica Partin
 */

//import the scanner
import java.util.Scanner;
import java.util.Random;


public class GuessGame{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //random number generator 
         Random generator = new Random(); 
  
         //import the scanner for prompt
Scanner input = new Scanner(System.in);

//integers for the secret number, input guess of the secret number, tries and limit to tries
int numberToGuess = 1 + generator.nextInt(100); 
int numberOfTries = 1; 
int limit= 10;
int guess=0;

//prompt user to enter a number to guess
System.out.println ("You have 10 tries to guess a number between 1 and 100");


//start of while loop

do{

    System.out.print("Guess number " + numberOfTries + ": ");
    guess= input.nextInt();
   //if else statements (outputs)
    
    if(numberOfTries >= 10){
    System.out.println("Sorry, you did not guess the guess the answer in 10 tries");   
    System.out.println("The number was " +numberToGuess); 
    System.exit(0);
    }
    else{
    if (guess > 100 || guess < 0){
        System.out.println("Guesses should be between 1 and 100.");
    }
    if (guess < numberToGuess && guess >= 0) {
         System.out.println("Your guess is too low. Try again.");
         numberOfTries++;
    }
    if (guess > numberToGuess && guess <= 100){
        System.out.println("Too high. Try again.");
        numberOfTries++;
    }
    if (guess == numberToGuess){
        System.out.println("Congratulations! You have correctly guess the number in " +numberOfTries+ " tries");
        System.exit(0);
    } 
    }
    } while(guess != numberToGuess ); 
        System.out.println("Sorry, you did not guess the guess the answer in 10 tries");
        System.out.println("The number was " +numberToGuess);
      
  }
}

    



//break to end while loop
    
  
        
  
    
 // If statement after executing the while loop the output if user loses and answer to secret number

    
    



    

